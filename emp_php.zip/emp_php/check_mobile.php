<?php

$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);

$mobile =$decoded_data['mobile'];

$connection = mysqli_connect('localhost','root','');


mysqli_select_db($connection , 'employeedetails');

$result = mysqli_query($connection , "select E_id from personaldetails  where Contact = '$mobile' ");

                                                                                                         
if(mysqli_num_rows($result) > 0 )
{
	
	
	$key['key']="done";
	$r = mysqli_fetch_array($result);
	$key['eid'] = $r['E_id'];
	
	echo json_encode($key);
	
	
}
else
{
	$key['key']="not done";
	echo json_encode($key);
}
	?>