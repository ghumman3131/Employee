<?php

$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);
$eid=$decoded_data['emp_id'];
$from=$decoded_data['DateFrom'];
$type=$decoded_data['leave_type'];
$to=$decoded_data['DateTo'];
$first=$decoded_data['day_half'];
$days=$decoded_data['days'];
$reason=$decoded_data['reason'];
$connection = mysqli_connect('localhost','root','');

//{"leave_type":"Academic","emp_id":"e001","DateFrom":"29\/4\/2017","DateTo":"29\/4\/2017","day_half":"full day","days":"4","reason":"gs"}

mysqli_select_db($connection , 'employeedetails');

$result = mysqli_query($connection , "insert into leave_apply (E_id,l_type,date_from,date_to,day_half,no_days,reason) values ('$eid','$type','$from','$to','$first','$days','$reason')");


if($result)
{
	
	
	$key['key']="done";
	echo json_encode($key);
	
	
}
else
{
	$key['key']="not done";
	echo json_encode($key);
}
	?>