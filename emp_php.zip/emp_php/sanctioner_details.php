
<?php

$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);
$id=$decoded_data['key_id'];


$connection = mysqli_connect('localhost','root','');

mysqli_select_db($connection , 'employeedetails');

$result = mysqli_query($connection , "select * from sanctioner_details where S_id='$id'");

$no_of_rows=mysqli_num_rows($result);	
if($no_of_rows>0)
{
	$row=mysqli_fetch_array($result);
	$response['name'] =      $row['E_Name'];
	$response['dob'] =      $row['DOB'];
	$response['father']=    $row['Father'];
	$response['mother'] =      $row['Mother'];
	$response['marital'] =      $row['MaritalStatus'];
	$response['spouse']=    $row['Spouse'];
	$response['address'] =      $row['Address'];
	$response['contact']=    $row['Contact'];	
	echo json_encode($response);
	
	
	
}
else
{
	$key['pass_key']="no user";
	echo json_encode($key);
}
	?>