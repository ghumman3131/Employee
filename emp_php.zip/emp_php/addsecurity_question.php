<?php


$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);
$output=$decoded_data['emp'];
$answer=$decoded_data['ans'];
$question = $decoded_data['ques'];


$connection = mysqli_connect('localhost','root','');

mysqli_select_db($connection , 'employeedetails');

$result = mysqli_query($connection , "insert into  security ( E_id , ques , answer  ) values ('$output'  , '$question' , '$answer')");

if($result){

		$key['key']="done";
		echo json_encode($key);
	}
	

else
{
	$key['key']="not done";
	echo json_encode($key);
}
	?>