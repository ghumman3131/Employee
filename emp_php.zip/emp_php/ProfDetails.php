<?php

$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);
$id=$decoded_data['key_id'];


$connection = mysqli_connect('localhost','root','');

mysqli_select_db($connection , 'employeedetails');

$result = mysqli_query($connection , "select * from profdetails where E_id='$id'");

$no_of_rows=mysqli_num_rows($result);	
if($no_of_rows>0)
{
	$row=mysqli_fetch_array($result);
	
	$response['department'] =      $row['Department'];
	$response['designation']=    $row['Designation'];
	$response['matric'] =      $row['Matric'];
	$response['highsch'] =      $row['HighSchool'];
	$response['grad']=    $row['Graduation'];
	$response['p_grad'] =      $row['PostGraduation'];
	$response['rewards']=    $row['Rewards'];	
	$response['exp'] =      $row['Exp'];
	$response['fos']=    $row['FieldOfSp'];	
	echo json_encode($response);
	
	
	
}
else
{
	$key['pass_key']="no user";
	echo json_encode($key);
}
	?>