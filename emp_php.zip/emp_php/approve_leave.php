<?php

$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);
$leave_id=$decoded_data['leave_id'];

$connection = mysqli_connect('localhost','root','');


mysqli_select_db($connection , 'employeedetails');

$result = mysqli_query($connection , "update leave_apply set status = 'A' where leave_id = '$leave_id'");

                                                                                                         
if($result)
{
	
	
	$key['key']="done";
	echo json_encode($key);
	
	
}
else
{
	$key['key']="not done";
	echo json_encode($key);
}
	?>