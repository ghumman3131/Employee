<?php

$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);
$output=$decoded_data['emp'];
$answer=$decoded_data['ans'];
$question = $decoded_data['ques'];


$connection = mysqli_connect('localhost','root','');

mysqli_select_db($connection , 'employeedetails');

$result = mysqli_query($connection , "select * from security where E_id='$output' ");

$no_of_rows=mysqli_num_rows($result);	
if($no_of_rows>0)
{
	$row=mysqli_fetch_array($result);
	$saved_answer=$row['answer'];
	$saved_quesion=$row['ques'];
	if($saved_answer==$answer && $saved_quesion==$question)
	{ $key['pass_key']="answer matched";
        echo json_encode($key);
	}
	else
	{
		$key['pass_key']="incorrect answer";
		echo json_encode($key);
	}
	
}
else
{
	$key['pass_key']="wrong question";
	echo json_encode($key);
}
	?>