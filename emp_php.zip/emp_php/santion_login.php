<?php

$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);
$out1=$decoded_data['name'];
$out2=$decoded_data['pas'];

$connection = mysqli_connect('localhost','root','');

mysqli_select_db($connection , 'employeedetails');

$result = mysqli_query($connection , "select * from sanction_login where employ_id='$out1'");

$no_of_rows=mysqli_num_rows($result);	
if($no_of_rows>0)
{
	$row=mysqli_fetch_array($result);
	$saved_password=$row['password'];
	if($saved_password==$out2)
	{ $key['pass_key']="password matched";
echo json_encode($key);
	}
	else
	{
		$key['pass_key']="Enter Correct password";
		echo json_encode($key);
	}
	
}
else
{
	$key['pass_key']="no user";
	echo json_encode($key);
}
	?>