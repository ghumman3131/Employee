<?php



date_default_timezone_set('Asia/Kolkata');

$date = date('d/m/Y', time());
$response;



$connection = mysqli_connect('localhost','root','');


mysqli_select_db($connection , 'employeedetails');

$result_academic = mysqli_query($connection , "select a.E_id , b.E_Name from leave_apply a , personaldetails b where a.status= 'A' and a.date_from = '5/5/2017' and b.E_id = a.E_id");


while($r = mysqli_fetch_assoc($result_academic))
	$output[] = $r ;


$response['today_leaves'] = $output ;


echo json_encode($response);



?>