<?php

$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);

$emp_id = $decoded_data['key_id'];

$connection = mysqli_connect('localhost','root','');


mysqli_select_db($connection , 'employeedetails');

$result_academic = mysqli_query($connection , "select * from leave_apply where E_id= '$emp_id' and status = 'A' and l_type = 'Academic'");



$result_casual = mysqli_query($connection , "select * from leave_apply where E_id= '$emp_id' and status = 'A' and l_type = 'Casual'");


$result_medical = mysqli_query($connection , "select * from leave_apply where E_id= '$emp_id' and status = 'A' and l_type = 'Medical'");


$response['num_academic'] = 10 - mysqli_num_rows($result_academic);

$response['num_casual'] =  10 - mysqli_num_rows($result_casual);

$response['num_medical'] = 10 - mysqli_num_rows($result_medical);

echo json_encode($response);



?>