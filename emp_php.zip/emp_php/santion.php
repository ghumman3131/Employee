<?php

$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);
$output=$decoded_data['sanid'];
$output2=$decoded_data['sanpass'];

$connection = mysqli_connect('localhost','root','');

mysqli_select_db($connection , 'employeedetails');

$result = mysqli_query($connection , "select * from sanction_login where employ_id='$output' and password = '$output2'");

$no_of_rows=mysqli_num_rows($result);	
if($no_of_rows>0)
{
	 $key['pass_key']="password matched";
echo json_encode($key);
	
	
}
else
{
	$key['pass_key']="no user";
	echo json_encode($key);
}
	?>[