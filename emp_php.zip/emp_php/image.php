<?php
   $json = file_get_contents('php://input');
    //convert json object to php associative array
   $data = json_decode($json, true);
   
   $eid = $data['eid'];
 
   $db = mysqli_connect("localhost","root", ""); 
  
   mysqli_select_db($db, 'employeedetails'); // your database name here
   
   $query = mysqli_query($db,"select image_id from personaldetails where E_id = '$eid'");
   
   
 
  
  echo json_encode( mysqli_fetch_assoc($query));
    
    
    ?>