<?php

$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);
$id=$decoded_data['key_id'];


$connection = mysqli_connect('localhost','root','');

mysqli_select_db($connection , 'employeedetails');

$result = mysqli_query($connection , "select * from healthdetails where E_id='$id'");

$no_of_rows=mysqli_num_rows($result);	
if($no_of_rows>0)
{
	$row=mysqli_fetch_array($result);

	$response['ename'] =      $row['Ename'];
	$response['bgroup']=    $row['Bgroup'];
	$response['height'] =      $row['Height'];
	$response['weight'] =      $row['Weight'];
	echo json_encode($response);
	
	
	
}
else
{
	$key['pass_key']="no user";
	echo json_encode($key);
}
	?>