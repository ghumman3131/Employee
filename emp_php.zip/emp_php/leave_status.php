<?php

$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);

$emp_id = $decoded_data['key_id'];

$connection = mysqli_connect('localhost','root','');


mysqli_select_db($connection , 'employeedetails');

$status = mysqli_query($connection , "select status from leave_apply where E_id= 'e001' ");


$response['result'] = mysqli_fetch_assoc($status);


echo json_encode($response);



?>