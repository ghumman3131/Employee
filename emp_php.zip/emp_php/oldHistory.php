<?php

$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);

$emp_id = $decoded_data['employ_id'];

$connection = mysqli_connect('localhost','root','');

//{"leave_type":"Academic","emp_id":"e001","DateFrom":"29\/4\/2017","DateTo":"29\/4\/2017","day_half":"full day","days":"4","reason":"gs"}

mysqli_select_db($connection , 'employeedetails');

$result = mysqli_query($connection , "select * from history where E_id= '$emp_id'");


while($r = mysqli_fetch_assoc($result))
	
$output[] = $r; 

$response['result'] = $output;

echo json_encode($response);


?>