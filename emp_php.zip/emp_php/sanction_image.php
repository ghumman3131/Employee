<?php
   $json = file_get_contents('php://input');
    //convert json object to php associative array
   $data = json_decode($json, true);
   
   $sid = $data['sid'];
 
   $db = mysqli_connect("localhost","root", ""); 
  
   mysqli_select_db($db, 'employeedetails'); // your database name here
   
   $query = mysqli_query($db,"select image_id from sanctioner_details where S_id = '$sid'");
   
   
 
  
  echo json_encode( mysqli_fetch_assoc($query));
    
    
    ?>